console.log('B-Test script loaded');
